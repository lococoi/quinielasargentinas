import json
import os
import re
import warnings
from datetime import datetime

import requests
from bs4 import BeautifulSoup

# Ignorar advertencias de certificados y de parseo
warnings.filterwarnings("ignore")

URL = "https://apps.loteriasantafe.gov.ar:8443/Extractos/paginas/mostrarPoceadaFederal.xhtml"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
}

CARPETA = "poceada"

MESES = {
    "enero": 1,
    "febrero": 2,
    "marzo": 3,
    "abril": 4,
    "mayo": 5,
    "junio": 6,
    "julio": 7,
    "agosto": 8,
    "septiembre": 9,
    "octubre": 10,
    "noviembre": 11,
    "diciembre": 12,
}


def obtener_ultimo_id(carpeta):
    max_id = 0
    ruta_archivo = None
    if not os.path.exists(carpeta):
        return max_id, None
    for fname in os.listdir(carpeta):
        match = re.search(r"_(\d+)\.json$", fname)
        if match:
            num = int(match.group(1))
            if num > max_id:
                max_id = num
                ruta_archivo = os.path.join(carpeta, fname)
    return max_id, ruta_archivo


def procesar_datos_poceada(session, sorteo_str, id_sorteo, view_state, mes_anio_str):
    """Extrae los datos específicos de la Poceada Federal usando el mes/año del selector"""
    payload_sorteo = {
        "javax.faces.partial.ajax": "true",
        "javax.faces.source": "form:sorteoSeleccionado",
        "javax.faces.partial.execute": "form:sorteoSeleccionado",
        "javax.faces.partial.render": "form",
        "javax.faces.behavior.event": "change",
        "javax.faces.partial.event": "change",
        "form": "form",
        "form:sorteoSeleccionado_input": sorteo_str,
        "javax.faces.ViewState": view_state,
    }

    ajax_headers = HEADERS.copy()
    ajax_headers.update(
        {"Faces-Request": "partial/ajax", "X-Requested-With": "XMLHttpRequest"}
    )

    # Realizar la petición POST
    res_data = session.post(
        URL, data=payload_sorteo, headers=ajax_headers, verify=False
    )

    # Extraer el contenido del CDATA
    html_final_raw = re.search(r"<!\[CDATA\[(.*?)\]\]>", res_data.text, re.DOTALL)
    soup_final = BeautifulSoup(
        html_final_raw.group(1) if html_final_raw else res_data.text, "html.parser"
    )

    # --- LÓGICA DE FECHA ---
    # 1. Obtener día desde sorteo_str (ej: "Sábado 27 - 8666" -> 27)
    dia_match = re.search(r"(\d+)\s*-", sorteo_str)
    dia = int(dia_match.group(1)) if dia_match else datetime.now().day

    # 2. Obtener mes y año desde mes_anio_str (ej: "Diciembre 2025")
    mes_anio_match = re.search(r"(\w+)\s+(\d{4})", mes_anio_str.lower())
    mes = (
        MESES.get(mes_anio_match.group(1), datetime.now().month)
        if mes_anio_match
        else datetime.now().month
    )
    anio = int(mes_anio_match.group(2)) if mes_anio_match else datetime.now().year

    return {
        "sorteo": int(id_sorteo),
        "dia": dia,
        "mes": mes,
        "anio": anio,
        "loterias": {
            "POCEADA FEDERAL": [
                div.get_text(strip=True)
                for div in soup_final.find_all("div", class_="cuadradoPo")
            ]
        },
    }


def extraer_siguiente_poceada(session):
    os.makedirs(CARPETA, exist_ok=True)
    session.headers.update(HEADERS)

    # 1. Obtener último ID local
    ultimo_id, ruta_local = obtener_ultimo_id(CARPETA)

    # 2. Conexión inicial para obtener ViewState y Mes/Año seleccionado
    res_init = session.get(URL, headers=HEADERS, verify=False)
    soup_init = BeautifulSoup(res_init.text, "html.parser")
    view_state_tag = soup_init.find("input", {"name": "javax.faces.ViewState"})

    if not view_state_tag:
        return "❌ Error: No se pudo obtener el ViewState."

    view_state = view_state_tag["value"]

    # Obtener el mes/año seleccionado (ej: "Diciembre 2025")
    mes_anio_tag = soup_init.find("select", {"id": "form:mesSeleccionado_input"})
    mes_anio_str = (
        mes_anio_tag.find("option", selected=True).get_text(strip=True)
        if mes_anio_tag
        else ""
    )

    # Obtener las opciones de sorteos disponibles en el select
    opciones_sorteos = [
        opt.get_text(strip=True)
        for opt in soup_init.find_all("option")
        if " - " in opt.get_text()
    ]

    # --- PASO A: Comprobar cambios en el último ID ---
    if ultimo_id > 0 and ruta_local:
        sorteo_actual_str = next(
            (s for s in opciones_sorteos if s.endswith(str(ultimo_id))), None
        )
        if sorteo_actual_str:
            datos_online = procesar_datos_poceada(
                session, sorteo_actual_str, ultimo_id, view_state, mes_anio_str
            )
            with open(ruta_local, "r", encoding="utf-8") as f:
                datos_locales = json.load(f)

            if datos_online["loterias"] != datos_locales.get("loterias"):
                with open(ruta_local, "w", encoding="utf-8") as f:
                    json.dump(datos_online, f, indent=4, ensure_ascii=False)
                return f"🔄 Actualizado por cambios en web: {ruta_local}"

    # --- PASO B: Buscar siguiente ID ---
    siguiente_id = ultimo_id + 1
    sorteo_str = next(
        (s for s in opciones_sorteos if s.endswith(str(siguiente_id))), None
    )

    if not sorteo_str:
        return f"☕ No hay sorteos nuevos (buscando {siguiente_id})"

    resultado = procesar_datos_poceada(
        session, sorteo_str, siguiente_id, view_state, mes_anio_str
    )

    # Nombre de archivo con la fecha real extraída
    fecha_file = f"{resultado['anio']}-{resultado['mes']:02d}-{resultado['dia']:02d}"
    filename = os.path.join(CARPETA, f"poceada_{fecha_file}_{siguiente_id}.json")

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(resultado, f, indent=4, ensure_ascii=False)

    return f"✅ Guardado: {filename}"


if __name__ == "__main__":
    print(extraer_siguiente_poceada())
