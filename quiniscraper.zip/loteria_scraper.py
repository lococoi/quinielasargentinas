import json
import os
import re
import warnings
from datetime import datetime

import requests
from bs4 import BeautifulSoup

# Desactivar advertencias
warnings.filterwarnings("ignore")

URL = "https://apps.loteriasantafe.gov.ar:8443/Extractos/paginas/mostrarLoteria.xhtml"
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )
}

CARPETA = "loteria"

MESES_MAP = {
    "enero": 1,
    "febrero": 2,
    "marzo": 3,
    "abril": 4,
    "mayo": 5,
    "junio": 6,
    "julio": 7,
    "agosto": 8,
    "septiembre": 9,
    "octubre": 10,
    "noviembre": 11,
    "diciembre": 12,
}


def obtener_ultimo_id_y_ruta(carpeta):
    max_id = 0
    ruta_archivo = None

    if not os.path.exists(carpeta):
        return 0, None

    for fname in os.listdir(carpeta):
        match = re.search(r"_(\d+)\.json$", fname)
        if match:
            num = int(match.group(1))
            if num > max_id:
                max_id = num
                ruta_archivo = os.path.join(carpeta, fname)

    return max_id, ruta_archivo


def actualizar_view_state(html):
    match = re.search(r'id="javax.faces.ViewState".*?value="(.*?)"', html)
    return match.group(1) if match else None


def procesar_sorteo(session, mes_str, sorteo_str, view_state):
    """Extrae datos de Lotería usando la lógica de fecha corregida"""
    payload = {
        "javax.faces.partial.ajax": "true",
        "javax.faces.source": "form:sorteoSeleccionado",
        "javax.faces.partial.execute": "form:sorteoSeleccionado",
        "javax.faces.partial.render": "form",
        "javax.faces.behavior.event": "change",
        "javax.faces.partial.event": "change",
        "form": "form",
        "form:mesSeleccionado_input": mes_str,
        "form:sorteoSeleccionado_input": sorteo_str,
        "javax.faces.ViewState": view_state,
    }

    ajax_headers = HEADERS | {
        "Faces-Request": "partial/ajax",
        "X-Requested-With": "XMLHttpRequest",
    }

    res = session.post(URL, data=payload, headers=ajax_headers, verify=False)
    view_state = actualizar_view_state(res.text) or view_state

    html_raw = re.search(r"<!\[CDATA\[(.*?)\]\]>", res.text, re.DOTALL)
    soup = BeautifulSoup(
        html_raw.group(1) if html_raw else res.text,
        "html.parser",
    )

    # --- LÓGICA DE FECHA CORREGIDA ---
    # 1. Obtener mes y año del selector (ej: "Diciembre 2025")
    mes_anio_match = re.search(r"(\w+)\s+(\d{4})", mes_str.lower())
    nombre_mes = mes_anio_match.group(1) if mes_anio_match else ""
    anio = int(mes_anio_match.group(2)) if mes_anio_match else datetime.now().year

    # 2. Obtener día del texto del sorteo (ej: "Sábado 27 - 8666")
    dia_match = re.search(r"(\d+)\s*-", sorteo_str)
    dia = int(dia_match.group(1)) if dia_match else 1

    id_sorteo = int(sorteo_str.split("-")[-1].strip())

    # Extracciones (1° al 20°)
    extracciones = [
        d.get_text(strip=True) for d in soup.find_all("div", class_="numero_lot")
    ]

    # Terminaciones
    terminaciones = []
    term_panel = soup.find("div", {"id": "form:Terminaciones"})
    if term_panel:
        terminaciones = [
            d.get_text(strip=True)
            for d in term_panel.find_all("div", class_="numersorteoter")
            if d.get_text(strip=True).isdigit()
        ]

    # Aproximaciones
    aproximaciones = []
    aprox_panel = soup.find("div", {"id": "form:Aproximaciones"})
    if aprox_panel:
        aproximaciones = [
            d.get_text(strip=True)
            for d in aprox_panel.find_all("div", class_="numero_apr")
            if "$" not in d.get_text()
        ]

    # Extracciones 3 cifras
    extracciones_3 = []
    ext3_panel = soup.find("div", {"id": "form:contenedorext_3"})
    if ext3_panel:
        extracciones_3 = [
            d.get_text(strip=True)
            for d in ext3_panel.find_all("div", class_="numero_apr")
        ]

    return {
        "sorteo": id_sorteo,
        "dia": dia,
        "mes": MESES_MAP.get(nombre_mes, datetime.now().month),
        "anio": anio,
        "loterias": {
            "LOTERIA SANTA FE": extracciones,
            "TERMINACIONES": terminaciones,
            "APROXIMACIONES": aproximaciones,
            "EXTRACCIONES_3_CIFRAS": extracciones_3,
        },
    }, view_state


def extraer_siguiente_loteria(session):
    os.makedirs(CARPETA, exist_ok=True)
    session.headers.update(HEADERS)

    ultimo_id, ruta_local = obtener_ultimo_id_y_ruta(CARPETA)

    # Carga inicial
    res_init = session.get(URL, headers=HEADERS, verify=False)
    soup_init = BeautifulSoup(res_init.text, "html.parser")

    view_state_input = soup_init.find("input", {"name": "javax.faces.ViewState"})
    if not view_state_input:
        return "❌ Error: No se pudo obtener el ViewState."
    view_state = view_state_input["value"]

    # --- CORRECCIÓN: Obtener el mes seleccionado actualmente del selector ---
    mes_actual_tag = soup_init.find("select", {"id": "form:mesSeleccionado_input"})
    if mes_actual_tag:
        mes_str = mes_actual_tag.find("option", selected=True).get_text(strip=True)
    else:
        # Fallback si por alguna razón falla el select
        mes_str = f"{datetime.now().strftime('%B')} {datetime.now().year}"

    opciones_sorteos = [
        opt.get_text(strip=True)
        for opt in soup_init.find_all("option")
        if " - " in opt.get_text()
    ]

    siguiente_id = ultimo_id + 1
    sorteo_str = next(
        (s for s in opciones_sorteos if s.endswith(str(siguiente_id))),
        None,
    )

    if not sorteo_str:
        return f"☕ No hay sorteos nuevos (buscando {siguiente_id})."

    datos, view_state = procesar_sorteo(session, mes_str, sorteo_str, view_state)

    # Nombre de archivo dinámico
    fecha_fmt = f"{datos['anio']}-{datos['mes']:02d}-{datos['dia']:02d}"
    filename = os.path.join(CARPETA, f"loteria_{fecha_fmt}_{datos['sorteo']}.json")

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(datos, f, indent=4, ensure_ascii=False)

    return f"✅ Sorteo {datos['sorteo']} guardado correctamente en {filename}"


if __name__ == "__main__":
    print(extraer_siguiente_loteria())
