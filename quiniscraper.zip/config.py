# config.py
USE_PROXY = False  # ← toggle único

PROXIES = (
    {
        "http": "socks5h://127.0.0.1:1080",
        "https": "socks5h://127.0.0.1:1080",
    }
    if USE_PROXY
    else {}
)
