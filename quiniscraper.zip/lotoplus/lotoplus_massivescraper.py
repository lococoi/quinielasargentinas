import json
import re
from pathlib import Path

import requests
from bs4 import BeautifulSoup

BASE = "https://loto.loteriadelaciudad.gob.ar/"
AJAX = BASE + "resultadosLoto/consultaResultados.php"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0",
    "Accept": "*/*",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "X-Requested-With": "XMLHttpRequest",
    "Origin": BASE,
    "Referer": BASE,
}


session = requests.Session()
session.headers.update(HEADERS)


# -------------------------------------------------
# UTILIDADES
# -------------------------------------------------
def parse_fecha_sorteo(texto: str):
    """
    'Fecha: 10/01/2026 - Sorteo: 3847'
    """
    m = re.search(r"Fecha:\s*(\d{2})/(\d{2})/(\d{4})\s*-\s*Sorteo:\s*(\d+)", texto)
    if not m:
        raise ValueError(f"No se pudo parsear: {texto}")

    dia, mes, anio, sorteo = map(int, m.groups())
    return sorteo, anio, mes, dia


# -------------------------------------------------
# SCRAPER PRINCIPAL
# -------------------------------------------------
def descargar_lotoplus_descendente():
    # 1) GET HOME
    r = session.get(BASE, timeout=15)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")

    codigo = soup.select_one("#valor1")["value"]
    jurisdiccion = soup.select_one("#valor2")["value"]

    opciones = soup.select("#valor3 option")
    if not opciones:
        raise RuntimeError("No se encontraron sorteos en el selector")

    # 2) Iterar en orden descendente (como vienen en la web)
    for opt in opciones:
        texto = opt.get_text(strip=True)
        sorteo, anio, mes, dia = parse_fecha_sorteo(texto)

        filename = f"lotoplus_{anio}-{mes:02d}-{dia:02d}_{sorteo}.json"
        if filename.exists():
            print(f"[SKIP] {filename.name}")
            continue

        print(f"[INFO] Descargando sorteo {sorteo} ({dia:02d}/{mes:02d}/{anio})")

        payload = {
            "codigo": codigo,
            "juridiccion": jurisdiccion,
            "sorteo": sorteo,
        }

        r2 = session.post(AJAX, data=payload, timeout=15)
        r2.raise_for_status()

        soup_res = BeautifulSoup(r2.text, "html.parser")
        cont = soup_res.select_one(".multiplica")
        if not cont:
            print(f"[WARN] Sorteo {sorteo} sin resultados, se omite")
            continue

        # Número Plus
        plus_tag = cont.select_one(".multiplicador .circle")
        numero_plus = (
            int(plus_tag.get_text(strip=True))
            if plus_tag and plus_tag.get_text(strip=True).isdigit()
            else None
        )

        resultados = {"TRADICIONAL": [], "MATCH": [], "DESQUITE": [], "SALE O SALE": []}

        for g in cont.select(".grilla"):
            nombre = g.select_one(".label p")
            if not nombre:
                continue

            key = nombre.get_text(strip=True).upper()
            if key not in resultados:
                continue

            resultados[key] = [
                int(p.get_text(strip=True)) for p in g.select(".resultado .item-loto p")
            ]

        data = {
            "sorteo": sorteo,
            "dia": dia,
            "mes": mes,
            "anio": anio,
            "resultados": {**resultados, "NUMEROPLUS": numero_plus},
        }

        filename.write_text(
            json.dumps(data, indent=4, ensure_ascii=False), encoding="utf-8"
        )

        print(f"[OK] Guardado {filename.name}")


# -------------------------------------------------
# MAIN
# -------------------------------------------------
if __name__ == "__main__":
    descargar_lotoplus_descendente()
