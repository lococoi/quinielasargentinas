import json
import os
import re
import warnings
from datetime import datetime

import requests
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

URL = "https://apps.loteriasantafe.gov.ar:8443/Extractos/paginas/mostrarBrinco.xhtml"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
}

CARPETA = "brinco"

MESES = {
    "enero": 1,
    "febrero": 2,
    "marzo": 3,
    "abril": 4,
    "mayo": 5,
    "junio": 6,
    "julio": 7,
    "agosto": 8,
    "septiembre": 9,
    "octubre": 10,
    "noviembre": 11,
    "diciembre": 12,
}


def obtener_ultimo_id(carpeta):
    max_id = 0
    ruta_archivo = None
    if not os.path.exists(carpeta):
        return max_id, None
    for fname in os.listdir(carpeta):
        match = re.search(r"_(\d+)\.json$", fname)
        if match:
            num = int(match.group(1))
            if num > max_id:
                max_id = num
                ruta_archivo = os.path.join(carpeta, fname)
    return max_id, ruta_archivo


def procesar_datos_brinco(session, sorteo_str, id_sorteo, view_state, mes_anio_str):
    """Función interna para extraer los datos del HTML de Brinco usando el mes/año del selector"""
    payload_sorteo = {
        "javax.faces.partial.ajax": "true",
        "javax.faces.source": "form:sorteoSeleccionado",
        "javax.faces.partial.execute": "form:sorteoSeleccionado",
        "javax.faces.partial.render": "form",
        "javax.faces.behavior.event": "change",
        "javax.faces.partial.event": "change",
        "form": "form",
        "form:sorteoSeleccionado_input": sorteo_str,
        "javax.faces.ViewState": view_state,
    }

    ajax_headers = HEADERS.copy()
    ajax_headers.update(
        {"Faces-Request": "partial/ajax", "X-Requested-With": "XMLHttpRequest"}
    )

    res_data = session.post(URL, data=payload_sorteo, headers=ajax_headers)
    html_final = re.search(r"<!\[CDATA\[(.*?)\]\]>", res_data.text, re.DOTALL)
    soup_final = BeautifulSoup(
        html_final.group(1) if html_final else res_data.text, "html.parser"
    )

    # --- LÓGICA DE FECHA CORREGIDA ---
    # 1. Obtener día desde sorteo_str (ej: "Domingo 28 - 1234" -> 28)
    dia_match = re.search(r"(\d+)\s*-", sorteo_str)
    dia = int(dia_match.group(1)) if dia_match else datetime.now().day

    # 2. Obtener mes y año desde mes_anio_str (ej: "Diciembre 2025")
    mes_anio_match = re.search(r"(\w+)\s+(\d{4})", mes_anio_str.lower())
    mes = (
        MESES.get(mes_anio_match.group(1), datetime.now().month)
        if mes_anio_match
        else datetime.now().month
    )
    anio = int(mes_anio_match.group(2)) if mes_anio_match else datetime.now().year

    resultado = {
        "sorteo": int(id_sorteo),
        "dia": dia,
        "mes": mes,
        "anio": anio,
        "extracciones_principales": [],
        "brinco_junior": [],
    }

    paneles = soup_final.find_all("div", class_="contenedorquini1")
    for i, panel in enumerate(paneles):
        numeros = [
            b.get_text(strip=True)
            for b in panel.find_all("b")
            if b.get_text(strip=True).isdigit()
        ]
        if i == 0:
            resultado["extracciones_principales"] = numeros
        elif "Junior" in panel.get_text():
            resultado["brinco_junior"] = numeros

    return resultado


def extraer_siguiente_brinco(session):
    os.makedirs(CARPETA, exist_ok=True)
    session.headers.update(HEADERS)

    # 1. Obtener el último ID y su ruta
    ultimo_id, ruta_local = obtener_ultimo_id(CARPETA)

    # 2. Conexión inicial
    res_init = session.get(URL, headers=HEADERS)
    soup_init = BeautifulSoup(res_init.text, "html.parser")
    view_state = soup_init.find("input", {"name": "javax.faces.ViewState"})["value"]

    # --- EXTRAER MES Y AÑO DEL SELECTOR SUPERIOR ---
    mes_anio_tag = soup_init.find("select", {"id": "form:mesSeleccionado_input"})
    mes_anio_str = (
        mes_anio_tag.find("option", selected=True).get_text(strip=True)
        if mes_anio_tag
        else ""
    )

    opciones_sorteos = [
        opt.get_text(strip=True)
        for opt in soup_init.find_all("option")
        if " - " in opt.get_text()
    ]

    # --- PASO A: Comprobar si el último ID guardado cambió ---
    if ultimo_id > 0 and ruta_local:
        sorteo_actual_str = next(
            (s for s in opciones_sorteos if s.endswith(str(ultimo_id))), None
        )
        if sorteo_actual_str:
            datos_online = procesar_datos_brinco(
                session, sorteo_actual_str, ultimo_id, view_state, mes_anio_str
            )
            with open(ruta_local, "r", encoding="utf-8") as f:
                datos_locales = json.load(f)

            if datos_online != datos_locales:
                with open(ruta_local, "w", encoding="utf-8") as f:
                    json.dump(datos_online, f, indent=4, ensure_ascii=False)
                return f"🔄 Resultados actualizados: {ruta_local}"

    # --- PASO B: Intentar extraer el siguiente ID ---
    siguiente_id = ultimo_id + 1
    sorteo_str = next(
        (s for s in opciones_sorteos if s.endswith(str(siguiente_id))), None
    )

    if not sorteo_str:
        return f"☕ No hay sorteos nuevos (buscando {siguiente_id})."

    resultado = procesar_datos_brinco(
        session, sorteo_str, siguiente_id, view_state, mes_anio_str
    )

    fecha_str = f"{resultado['anio']}-{resultado['mes']:02d}-{resultado['dia']:02d}"
    filename = os.path.join(CARPETA, f"brinco_{fecha_str}_{siguiente_id}.json")

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(resultado, f, indent=4, ensure_ascii=False)

    return f"✅ Guardado nuevo sorteo: {filename}"


if __name__ == "__main__":
    print(extraer_siguiente_brinco())
