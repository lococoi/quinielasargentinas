import json
import os
import re

import requests
from bs4 import BeautifulSoup

BASE = "https://loto.loteriadelaciudad.gob.ar/"
AJAX = BASE + "resultadosLoto/consultaResultados.php"
CARPETA = "lotoplus"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0",
    "Accept": "*/*",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "X-Requested-With": "XMLHttpRequest",
    "Origin": BASE,
    "Referer": BASE,
}


# -------------------------------------------------
# UTILIDADES LOCALES
# -------------------------------------------------
def obtener_ultimo_id(carpeta):
    max_id = 0
    ruta = None
    if not os.path.exists(carpeta):
        return 0, None

    for f in os.listdir(carpeta):
        m = re.search(r"_(\d+)\.json$", f)
        if m:
            sid = int(m.group(1))
            if sid > max_id:
                max_id = sid
                ruta = os.path.join(carpeta, f)

    return max_id, ruta


def parse_fecha_y_sorteo(texto):
    m = re.search(r"Fecha:\s*(\d{2})/(\d{2})/(\d{4})\s*-\s*Sorteo:\s*(\d+)", texto)
    if not m:
        raise RuntimeError(f"No se pudo parsear: {texto}")

    dia, mes, anio, sorteo = map(int, m.groups())
    return sorteo, dia, mes, anio


# -------------------------------------------------
# EXTRACCIÓN DE UN SORTEO
# -------------------------------------------------
def obtener_resultado_lotoplus(session, codigo, jurisdiccion, sorteo, dia, mes, anio):
    payload = {
        "codigo": codigo,
        "juridiccion": jurisdiccion,
        "sorteo": sorteo,
    }

    r = session.post(AJAX, data=payload, timeout=15)
    r.raise_for_status()

    soup = BeautifulSoup(r.text, "html.parser")
    cont = soup.select_one(".multiplica")
    if not cont:
        return None

    plus_tag = cont.select_one(".multiplicador .circle")
    numero_plus = (
        int(plus_tag.get_text(strip=True))
        if plus_tag and plus_tag.get_text(strip=True).isdigit()
        else None
    )

    resultados = {"TRADICIONAL": [], "MATCH": [], "DESQUITE": [], "SALE O SALE": []}

    for g in cont.select(".grilla"):
        nombre = g.select_one(".label p")
        if not nombre:
            continue

        key = nombre.get_text(strip=True).upper()
        if key not in resultados:
            continue

        resultados[key] = [
            int(p.get_text(strip=True)) for p in g.select(".resultado .item-loto p")
        ]

    return {
        "sorteo": sorteo,
        "dia": dia,
        "mes": mes,
        "anio": anio,
        "resultados": {**resultados, "NUMEROPLUS": numero_plus},
    }


# -------------------------------------------------
# FUNCIÓN PRINCIPAL (equivalente a extraer_siguiente_poceada)
# -------------------------------------------------
def extraer_siguiente_lotoplus(session):
    os.makedirs(CARPETA, exist_ok=True)
    session.headers.update(HEADERS)

    # 1) último local
    ultimo_id, ruta_local = obtener_ultimo_id(CARPETA)

    # 2) home
    r = session.get(BASE, timeout=15)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")

    codigo = soup.select_one("#valor1")["value"]
    jurisdiccion = soup.select_one("#valor2")["value"]

    opciones = soup.select("#valor3 option")
    sorteos_web = []
    for opt in opciones:
        texto = opt.get_text(strip=True)
        sorteo, dia, mes, anio = parse_fecha_y_sorteo(texto)
        sorteos_web.append((sorteo, dia, mes, anio))

    sorteos_web.sort(reverse=True)

    # --- PASO A: revisar último ---
    if ultimo_id > 0 and ruta_local:
        actual = next((s for s in sorteos_web if s[0] == ultimo_id), None)
        if actual:
            sorteo, dia, mes, anio = actual
            datos_online = obtener_resultado_lotoplus(
                session, codigo, jurisdiccion, sorteo, dia, mes, anio
            )

            with open(ruta_local, "r", encoding="utf-8") as f:
                datos_locales = json.load(f)

            if datos_online and datos_online["resultados"] != datos_locales.get(
                "resultados"
            ):
                with open(ruta_local, "w", encoding="utf-8") as f:
                    json.dump(datos_online, f, indent=4, ensure_ascii=False)
                return f"🔄 Loto Plus actualizado por cambios: {ruta_local}"

    # --- PASO B: buscar siguiente ---
    siguiente = next((s for s in sorteos_web if s[0] > ultimo_id), None)
    if not siguiente:
        return f"☕ No hay sorteos nuevos (buscando {ultimo_id + 1})."

    sorteo, dia, mes, anio = siguiente
    resultado = obtener_resultado_lotoplus(
        session, codigo, jurisdiccion, sorteo, dia, mes, anio
    )

    fecha = f"{anio}-{mes:02d}-{dia:02d}"
    filename = os.path.join(CARPETA, f"lotoplus_{fecha}_{sorteo}.json")

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(resultado, f, indent=4, ensure_ascii=False)

    return f"✅ Loto Plus guardado: {filename}"


# -------------------------------------------------
if __name__ == "__main__":
    print(extraer_siguiente_lotoplus())
