import time
import urllib.parse

import requests
import schedule

from brinco_scraper import extraer_siguiente_brinco
from config import PROXIES
from loteria_scraper import extraer_siguiente_loteria
from lotoplus_scraper import extraer_siguiente_lotoplus
from poceada_scraper import extraer_siguiente_poceada
from quini6_scraper import extraer_siguiente_quini6
from santafe_scraper import extraer_siguiente_quiniela

OPT = {0: "nocturna", 1: "vespertina", 2: "matutina", 3: "la previa", 4: "el primero"}


def crear_session_proxy():
    session = requests.Session()
    session.proxies.update(PROXIES)
    session.verify = False  # opcional, útil si usás túneles
    return session


def tarea_maestra():
    log_acumulado = "Scraper Manager\n"
    print("\nScraper Manager")

    session = crear_session_proxy()

    try:
        # Quiniela
        for opcion in range(5):
            msg = f"\nQuiniela {OPT[opcion]}"
            print(msg)
            log_acumulado += msg + "\n"

            resultado = extraer_siguiente_quiniela(opcion, session)
            if resultado:
                print(resultado)
                log_acumulado += str(resultado) + "\n"

        juegos = [
            ("Poceada Federal", extraer_siguiente_poceada),
            ("Lotería Santa Fe", extraer_siguiente_loteria),
            ("Brinco", extraer_siguiente_brinco),
            ("Quini 6", extraer_siguiente_quini6),
            ("Loto Plus", extraer_siguiente_lotoplus),
        ]

        for nombre, funcion in juegos:
            msg = f"\n{nombre}"
            print(msg)
            log_acumulado += msg + "\n"

            resultado = funcion(session)
            if resultado:
                print(resultado)
                log_acumulado += str(resultado) + "\n"

        success_msg = "\n✅ Todos los extractores ejecutados correctamente."
        print(success_msg)
        log_acumulado += success_msg

    except Exception as e:
        error_msg = f"\n❌ Error en ejecución maestra: {e}"
        print(error_msg)
        log_acumulado += error_msg

    # --- ENVÍO DEL RESULTADO VÍA GET ---
    # send_msg(log_acumulado)


def send_msg(log_acumulado):
    try:
        # Codificamos el texto para que sea seguro en una URL
        log_codificado = urllib.parse.quote(log_acumulado)
        # Hacemos el GET al link X
        url_final = f"https://api.callmebot.com/whatsapp.php?phone=5493462390351&text={log_codificado}&apikey=5221256"

        # timeout para que no se trabe el script si el servidor no responde
        requests.get(url_final, timeout=10, verify=False)
        print(f"\n📡 Notificación enviada correctamente.")
    except Exception as ex:
        print(f"\n⚠️ No se pudo enviar la notificación: {ex}")


# Ejecutar inmediatamente para la prueba
tarea_maestra()

# Programar cada minuto (según tu código de schedule)
schedule.every(1).minutes.do(tarea_maestra)

print("\n⏳ Script maestro iniciado. Ejecutando...")

while True:
    schedule.run_pending()
    time.sleep(1)
