import json
import re
import warnings

import requests
from bs4 import BeautifulSoup

warnings.filterwarnings("ignore")

# URL específica de la Poceada Federal
URL = "https://apps.loteriasantafe.gov.ar:8443/Extractos/paginas/mostrarPoceadaFederal.xhtml"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

MESES_MAP = {
    "Enero": 1,
    "Febrero": 2,
    "Marzo": 3,
    "Abril": 4,
    "Mayo": 5,
    "Junio": 6,
    "Julio": 7,
    "Agosto": 8,
    "Septiembre": 9,
    "Octubre": 10,
    "Noviembre": 11,
    "Diciembre": 12,
}


def extraer_poceada():
    session = requests.Session()

    try:
        print("--- INICIANDO EXTRACCIÓN POCEADA FEDERAL ---")
        res_init = session.get(URL, headers=HEADERS, verify=False)
        soup_init = BeautifulSoup(res_init.text, "html.parser")

        select_mes = soup_init.find("select", {"id": "form:mesSeleccionado_input"})
        meses_disponibles = [
            opt.get_text(strip=True) for opt in select_mes.find_all("option")
        ]

        # Filtramos por meses de 2025
        meses_a_procesar = [m for m in meses_disponibles if "2025" in m]

        for mes_str in meses_a_procesar:
            view_state = soup_init.find("input", {"name": "javax.faces.ViewState"})[
                "value"
            ]

            payload_mes = {
                "javax.faces.partial.ajax": "true",
                "javax.faces.source": "form:mesSeleccionado",
                "javax.faces.partial.execute": "form:mesSeleccionado",
                "javax.faces.partial.render": "form",
                "javax.faces.behavior.event": "change",
                "javax.faces.partial.event": "change",
                "form": "form",
                "form:mesSeleccionado_input": mes_str,
                "javax.faces.ViewState": view_state,
            }

            ajax_headers = HEADERS.copy()
            ajax_headers.update(
                {"Faces-Request": "partial/ajax", "X-Requested-With": "XMLHttpRequest"}
            )

            res_mes = session.post(
                URL, data=payload_mes, headers=ajax_headers, verify=False
            )

            new_vs = re.search(
                r'id="javax.faces.ViewState".*?value="(.*?)"', res_mes.text
            )
            if new_vs:
                view_state = new_vs.group(1)

            html_update = re.search(r"<!\[CDATA\[(.*?)\]\]>", res_mes.text, re.DOTALL)
            soup_mes = BeautifulSoup(
                html_update.group(1) if html_update else res_mes.text, "html.parser"
            )
            opciones_sorteos = [
                opt.get_text(strip=True)
                for opt in soup_mes.find_all("option")
                if " - " in opt.get_text()
            ]

            for sorteo_str in opciones_sorteos:
                payload_sorteo = {
                    "javax.faces.partial.ajax": "true",
                    "javax.faces.source": "form:sorteoSeleccionado",
                    "javax.faces.partial.execute": "form:sorteoSeleccionado",
                    "javax.faces.partial.render": "form",
                    "javax.faces.behavior.event": "change",
                    "javax.faces.partial.event": "change",
                    "form": "form",
                    "form:mesSeleccionado_input": mes_str,
                    "form:sorteoSeleccionado_input": sorteo_str,
                    "javax.faces.ViewState": view_state,
                }

                res_data = session.post(
                    URL, data=payload_sorteo, headers=ajax_headers, verify=False
                )
                html_final_raw = re.search(
                    r"<!\[CDATA\[(.*?)\]\]>", res_data.text, re.DOTALL
                )
                soup_final = BeautifulSoup(
                    html_final_raw.group(1) if html_final_raw else res_data.text,
                    "html.parser",
                )

                # Parse de Fecha e ID
                nombre_mes = mes_str.split()[0]
                anio = int(mes_str.split()[1])
                dia_match = re.search(r"(\d+)\s*-", sorteo_str)
                dia = int(dia_match.group(1)) if dia_match else 0
                id_sorteo = int(sorteo_str.split("-")[-1].strip())

                # --- EXTRACCIÓN DE NÚMEROS (Premios 1 al 20) ---
                # Según tu HTML, la clase es 'cuadradoPo'
                extracciones = [
                    div.get_text(strip=True)
                    for div in soup_final.find_all("div", class_="cuadradoPo")
                ]

                # Estructura final consolidada
                resultado = {
                    "sorteo": id_sorteo,
                    "dia": dia,
                    "mes": MESES_MAP.get(nombre_mes),
                    "anio": anio,
                    "loterias": {"POCEADA FEDERAL": extracciones},
                }

                filename = f"poceada_{anio}-{MESES_MAP.get(nombre_mes):02d}-{dia:02d}_{id_sorteo}.json"
                with open(filename, "w", encoding="utf-8") as f:
                    json.dump(resultado, f, indent=4, ensure_ascii=False)

                print(f"✅ Poceada Sorteo {id_sorteo} guardado.")

        print("\n--- PROCESO FINALIZADO ---")

    except Exception as e:
        print(f"❌ Error: {e}")


if __name__ == "__main__":
    extraer_poceada()
